import { useCallback } from 'react'
import Particles from '@tsparticles/react'
import { loadSlim } from '@tsparticles/slim'

export default function ParticlesBg({ variant = 'default' }) {
  const particlesInit = useCallback(async (engine) => {
    await loadSlim(engine)
  }, [])

  const configs = {
    default: {
      particles: {
        number: { value: 50, density: { enable: true, area: 1000 } },
        color: { value: ['#3b82f6', '#8b5cf6', '#06b6d4'] },
        shape: { type: 'circle' },
        opacity: { value: { min: 0.1, max: 0.4 } },
        size: { value: { min: 1, max: 3 } },
        move: {
          enable: true,
          speed: 0.8,
          direction: 'none',
          random: true,
          straight: false,
          outModes: { default: 'out' },
        },
        links: {
          enable: true,
          distance: 150,
          color: '#3b82f6',
          opacity: 0.1,
          width: 1,
        },
      },
      interactivity: {
        events: {
          onHover: { enable: true, mode: 'grab' },
        },
        modes: {
          grab: { distance: 140, links: { opacity: 0.3 } },
        },
      },
    },
    stars: {
      particles: {
        number: { value: 80, density: { enable: true, area: 800 } },
        color: { value: '#ffffff' },
        shape: { type: 'circle' },
        opacity: { value: { min: 0.1, max: 0.5 }, animation: { enable: true, speed: 1, minimumValue: 0.1 } },
        size: { value: { min: 0.5, max: 2 } },
        move: {
          enable: true,
          speed: 0.3,
          direction: 'none',
          random: true,
        },
      },
    },
  }

  return (
    <Particles
      className="absolute inset-0"
      init={particlesInit}
      options={{
        fullScreen: false,
        background: { color: { value: 'transparent' } },
        fpsLimit: 60,
        ...configs[variant],
      }}
    />
  )
}
