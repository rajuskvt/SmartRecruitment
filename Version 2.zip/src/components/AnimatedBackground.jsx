import { motion } from 'framer-motion'

export default function AnimatedBackground({ variant = 'mesh' }) {
  if (variant === 'mesh') {
    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full mesh-gradient opacity-40" />
        <div 
          className="absolute top-1/4 -left-32 w-[500px] h-[500px] rounded-full blur-[120px] animate-blob"
          style={{ backgroundColor: 'rgb(var(--color-accent-1) / 0.12)' }}
        />
        <div 
          className="absolute top-1/3 -right-32 w-[400px] h-[400px] rounded-full blur-[120px] animate-blob animation-delay-2000"
          style={{ backgroundColor: 'rgb(var(--color-accent-2) / 0.1)' }}
        />
        <div 
          className="absolute -bottom-32 left-1/3 w-[600px] h-[600px] rounded-full blur-[150px] animate-blob animation-delay-4000"
          style={{ backgroundColor: 'rgb(var(--color-accent-1) / 0.08)' }}
        />
      </div>
    )
  }

  if (variant === 'aurora') {
    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="aurora-bg absolute inset-0" />
        <div 
          className="absolute top-0 left-1/4 w-[800px] h-[600px] animate-morph"
          style={{ 
            background: 'radial-gradient(ellipse at center, rgb(var(--color-accent-1) / 0.1), transparent 60%)',
            filter: 'blur(60px)'
          }}
        />
        <div 
          className="absolute bottom-0 right-1/4 w-[600px] h-[500px] animate-morph animation-delay-4000"
          style={{ 
            background: 'radial-gradient(ellipse at center, rgb(var(--color-accent-2) / 0.08), transparent 60%)',
            filter: 'blur(60px)'
          }}
        />
      </div>
    )
  }

  if (variant === 'grid') {
    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 grid-pattern" />
        <div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full"
          style={{ 
            background: 'radial-gradient(circle, rgb(var(--color-accent-1) / 0.08), transparent 60%)',
            filter: 'blur(40px)'
          }}
        />
      </div>
    )
  }

  if (variant === 'dots') {
    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 dots-pattern opacity-50" />
        <div 
          className="absolute top-20 right-20 w-[300px] h-[300px] rounded-full blur-[100px] animate-float"
          style={{ backgroundColor: 'rgb(var(--color-accent-1) / 0.1)' }}
        />
        <div 
          className="absolute bottom-20 left-20 w-[250px] h-[250px] rounded-full blur-[100px] animate-float-delayed"
          style={{ backgroundColor: 'rgb(var(--color-accent-2) / 0.08)' }}
        />
      </div>
    )
  }

  if (variant === 'orbs') {
    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: `${150 + i * 50}px`,
              height: `${150 + i * 50}px`,
              top: `${10 + i * 15}%`,
              left: `${5 + i * 20}%`,
              background: `radial-gradient(circle, rgb(var(${i % 2 === 0 ? '--color-accent-1' : '--color-accent-2'}) / ${0.06 + i * 0.02}), transparent 70%)`,
              filter: 'blur(40px)',
            }}
            animate={{
              y: [0, -20 - i * 5, 0],
              x: [0, 10 + i * 3, 0],
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 5 + i * 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>
    )
  }

  return null
}
